package ir.yazdetemad.shortcut;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String URL = "https://yazdetemad.ir";
    private static final String PREFS = "samane_prefs";
    private static final String KEY_SHORTCUT_REQUESTED = "shortcut_requested";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createPinnedShortcutOnce();
        openWebsite();
        finish();
    }

    private void createPinnedShortcutOnce() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (prefs.getBoolean(KEY_SHORTCUT_REQUESTED, false)) return;

        ShortcutManager manager = getSystemService(ShortcutManager.class);
        if (manager == null || !manager.isRequestPinShortcutSupported()) {
            Toast.makeText(this, "افزودن میانبر از صفحه اصلی در این دستگاه پشتیبانی نمی‌شود.", Toast.LENGTH_LONG).show();
            return;
        }

        Intent launchIntent = new Intent(this, MainActivity.class);
        launchIntent.setAction(Intent.ACTION_VIEW);
        launchIntent.setData(Uri.parse(URL));

        ShortcutInfo shortcut = new ShortcutInfo.Builder(this, "samane-etemad-web")
                .setShortLabel("سامانه اعتماد")
                .setLongLabel("باز کردن سامانه اعتماد")
                .setIcon(Icon.createWithResource(this, ir.yazdetemad.shortcut.R.mipmap.ic_launcher))
                .setIntent(launchIntent)
                .build();

        boolean accepted = manager.requestPinShortcut(shortcut, null);
        if (accepted) {
            // Android may still show a system confirmation; this only records that the request was submitted.
            prefs.edit().putBoolean(KEY_SHORTCUT_REQUESTED, true).apply();
        }
    }

    private void openWebsite() {
        Intent browser = new Intent(Intent.ACTION_VIEW, Uri.parse(URL));
        browser.addCategory(Intent.CATEGORY_BROWSABLE);
        try {
            startActivity(browser);
        } catch (Exception e) {
            Toast.makeText(this, "مرورگری برای باز کردن سایت پیدا نشد.", Toast.LENGTH_LONG).show();
        }
    }
}
